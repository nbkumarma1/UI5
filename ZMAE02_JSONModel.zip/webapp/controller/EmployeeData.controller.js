sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("MaheshZMAE02_JSONModel.controller.EmployeeData", {

		onInit: function() {

			var employeeData = {
				"EmpId": "002P6C",
				"EmpName": "Mahesh Kumar"
			};
			//instantiate the Model
			var jsonmodelEmpdata = new sap.ui.model.json.JSONModel();
			jsonmodelEmpdata.setData(employeeData);

			//Bind the model at view level WITH Refrence X (Three possibility Bind at Application/View/Control/)
			this.getView().setModel(jsonmodelEmpdata,"X");
			
			var employeeData1 = {
				"EmpId": "05427J",
				"EmpName": "Mahesh Kumar"
			};
			//instantiate the Model
			var jsonmodelEmpdata1 =  new sap.ui.model.json.JSONModel();
			jsonmodelEmpdata1.setData(employeeData1);

			//Bind the model at view level WITH Refrence Y (Three possibility Bind at Application/View/Control/)
			this.getView().setModel(jsonmodelEmpdata1,"Y");
			
		}

	});
});