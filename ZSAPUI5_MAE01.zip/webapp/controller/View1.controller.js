sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("maheshZSAPUI5_MAE01.controller.View1", {
		_onInit: function() {
			sap.m.MessageToast.show("Hello Mahesh");
		},
		_submit: function() {
			sap.m.MessageToast.show("Submit Button is clicked");
		},
		_input: function() {
			sap.m.MessageToast.show("Button is clicked INPUT");
		},
		_input2: function() {
			var name = this.byId("id2").getValue();
			sap.m.MessageToast.show("Button is clicked for value " + name);
		},
		_GenderSelection: function() {
			if (this.byId("RB2").getSelected() === true) {
				var name = this.byId("id2").getValue();
				sap.m.MessageToast.show("Mrs." + name + "Welcome to UI5");
			} else
			{
				var name1 = this.byId("id2").getValue();
				sap.m.MessageToast.show("Mr." + name1 + "Welcome to UI5");
			}

		},
		onInit: function() {
			this._onInit();
			this.byId("id1").setText("Login");
			this.byId("id1").setEnabled(true);
			this.byId("id2").setValue("Mahesh");
		}
	});
});